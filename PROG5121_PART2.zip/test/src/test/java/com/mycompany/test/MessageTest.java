package com.mycompany.test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    // Message length test
    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message("0000000001", "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longText = "A".repeat(255); // 255 characters (5 over the limit)
        Message msg = new Message("0000000001", "+27718693002", longText);
        assertEquals("Message exceeds 250 characters by 5; please reduce the size.", msg.checkMessageLength());
    }

    // Recipient number format tests
    @Test
    public void testRecipientNumberSuccess() {
        Message msg = new Message("0000000001", "+27718693002", "Valid text");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testRecipientNumberFailure() {
        Message msg = new Message("0000000001", "0718693002", "Valid text");
        String expectedError = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        assertEquals(expectedError, msg.checkRecipientCell());
    }

    // Hash value matching test
    @Test
    public void testMessageHashCorrect() {
        Message msg = new Message("0000000001", "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", msg.createMessageHash());
    }

    // Loop hash verification
    @Test
    public void testMessageHashesInLoop() {
        String[] loopMessages = {"Hello world", "Testing loops now", "Final loop array items"};
        for (String txt : loopMessages) {
            Message msg = new Message("1100000000", "+27718693002", txt);
            assertNotNull(msg.createMessageHash());
        }
    }

    // Message ID created test
    @Test
    public void testMessageIDCreated() {
        Message msg = new Message("0123456789", "+27718693002", "Content");
        assertEquals("Message ID generated: 0123456789", msg.getIDGenerationStatus());
    }

    // Message sent status return tests
    @Test
    public void testMessageSentActions() {
        Message msg = new Message("0000000001", "+27718693002", "Content");
        
        // Send Message
        assertEquals("Message successfully sent.", msg.simulateActionStatus(1));
        
        // Disregard Message
        assertEquals("Press 0 to delete the message.", msg.simulateActionStatus(2));
        
        // Store Message
        assertEquals("Message successfully stored.", msg.simulateActionStatus(3));
    }
}
