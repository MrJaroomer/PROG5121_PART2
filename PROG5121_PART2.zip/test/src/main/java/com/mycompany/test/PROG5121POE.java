package com.mycompany.test;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
import javax.swing.*;

public class PROG5121POE {
    
    // Defines a data template to hold registered user details
    public static class User {
        public String username;
        public String password;
        public String phoneNumber;

        public User(String username, String password, String phoneNumber) {
            this.username = username;
            this.password = password;
            this.phoneNumber = phoneNumber;
        }
    }
    
    // Creates global variables to store users, scan inputs, and track counts
    public static ArrayList<User> userList = new ArrayList<>();
    public static Scanner scanner = new Scanner(System.in);
    public static int messageNumber = 0;
    public static int totalMessagesSent = 0;

    // Starts the main application loop and displays the authentication menu
    public static void main(String[] args) {
        while (true) {
            System.out.println("---User Authentication---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            
            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                register();
            } else if (choice.equals("2")) {
                login();
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    // Handles new account creation with username, password, and phone checks
    public static void register() {
        String username = "";
        boolean isUsernameValid = false;

        // Loops until a valid username with an underscore and max 5 characters is given
        while (!isUsernameValid) {
            System.out.print("Enter username: ");
            username = scanner.nextLine();

            // Verifies if the username meets the formatting requirements
            boolean meetsRequirements = username.contains("_") && username.length() <= 5;
            if (!meetsRequirements) {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
                continue; 
            }

            // Checks the user list to prevent duplicate usernames
            boolean alreadyExists = false;
            for (User u : userList) {
                if (u.username.equals(username)) {
                    alreadyExists = true;
                    break;
                }
            }

            if (alreadyExists) {
                System.out.println("Error: User already exists! Try another.");
            } else {
                isUsernameValid = true; 
                System.out.println("Username successfully captured.");
            }
        }

        String pass = "";
        boolean isPasswordValid = false;
        
        // Loops until a secure password with length, uppercase, number, and symbol is given
        while (!isPasswordValid) {
            System.out.print("Enter password: ");
            pass = scanner.nextLine();

            boolean hasLength = pass.length() >= 8;
            boolean hasUpper = false;
            boolean hasDigit = false;
            boolean hasSpecial = false;
            String specialChars = "!@#$%^&*()-_=+[]{}|;:',.<>/?";

            // Password specifications
            for (char c : pass.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (specialChars.contains(String.valueOf(c))) hasSpecial = true;
            }

            if (hasLength && hasUpper && hasDigit && hasSpecial) {
                isPasswordValid = true;
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String fullPhone = "";
        boolean isPhoneValid = false;
        String saSuffixRegex = "^[6-8][0-9]{8}$";

        // South african phone number specifications
        while (!isPhoneValid) {
            System.out.print("Enter SA cellphone number: +27 "); 
            String suffix = scanner.nextLine().trim().replaceAll("[\\s-]", "");

            // Uses regex to check if the suffix matches valid South African network digit structures
            if (!Pattern.matches(saSuffixRegex, suffix)) {
                System.out.println("Cell phone number incorrectly formatted.");
                continue;
            }

            fullPhone = "+27" + suffix;

            // stops multiple accounts from having the same number
            boolean phoneInUse = false;
            for (User u : userList) {
                if (u.phoneNumber.equals(fullPhone)) {
                    phoneInUse = true;
                    break;
                }
            }

            if (phoneInUse) {
                System.out.println("Error: This phone number is already registered to another account.");
            } else {
                isPhoneValid = true;
                System.out.println("Cell phone number +27 " + suffix + " has been successfully added.");
            }
        }
        
        // saves user information
        userList.add(new User(username, pass, fullPhone)); 
        System.out.println("Registration complete! All data stored.");
    }

    // Logs the user in and opens the app menu
    public static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String pass = scanner.nextLine();

        // Searches for a matching account in the stored records
        for (User u : userList) {
            if (u.username.equals(username) && u.password.equals(pass)) {
                JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
                launchQuickChat(); 
                return;
            }
        }
        System.out.println("Username or password incorrect, please try again.");
    }

    // creates QuickChat
    public static void launchQuickChat() {
        boolean keepRunning = true;

        JFrame topFrame = new JFrame();
        topFrame.setAlwaysOnTop(true);
        topFrame.setLocationRelativeTo(null);

        // Loops the menu buttons until the user exits
        while (keepRunning) {
            String[] options = {"Send Messages", "Coming Soon", "Quit"};
            
            int choice = JOptionPane.showOptionDialog(
                    topFrame, 
                    "Choose an option:", 
                    "Main Menu", 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    options, 
                    options
            );

            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> JOptionPane.showMessageDialog(topFrame, "Coming Soon.");
                case 2, -1 -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(topFrame, "Goodbye!");
                }
            }
        }
        topFrame.dispose();
    }

    // Loops through each message to prompt and capture inputs
    public static void sendMessages() {
        JFrame topFrame = new JFrame();
        topFrame.setAlwaysOnTop(true);
        topFrame.setLocationRelativeTo(null);

        String countInput = JOptionPane.showInputDialog(topFrame, "How many messages would you like to send?");
        if (countInput == null || countInput.trim().isEmpty()) {
            topFrame.dispose();
            return;
        }
        
        int count;
        // Checks if the user typed a valid whole number
        try {
            count = Integer.parseInt(countInput.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(topFrame, "Please enter a valid whole number.");
            topFrame.dispose();
            return;
        }

        int sessionMessagesSent = 0;

        // Processes each message one by one inside the loop count
        for (int i = 0; i < count; i++) {
            String randomID = String.format("%010d", new Random().nextInt(1_000_000_000));
            
            String recipient = JOptionPane.showInputDialog(topFrame, "Enter recipient cell number (+27XXXXXXXXX):");
            if (recipient == null) { topFrame.dispose(); return; }

            // Converts local cell numbers starting with 0 into the +27 format
            recipient = recipient.trim().replaceAll("[\\s-]", "");
            if (recipient.startsWith("0") && recipient.length() == 10) {
                recipient = "+27" + recipient.substring(1);
            }

            Message currentMessage = new Message(randomID, recipient, "");

            // Checks if the phone number is valid before continuing
            String cellValidation = currentMessage.checkRecipientCell();
            if (!cellValidation.equals("Cell phone number successfully captured.")) {
        JOptionPane.showMessageDialog(topFrame, cellValidation);
                i--;
                continue; 
            }

            String messageText = "";
            // Keeps asking for the message text until it is typed correctly
            while (true) {
                messageText = JOptionPane.showInputDialog(topFrame, "Enter message content (max 250 characters):");
                if (messageText == null) { topFrame.dispose(); return; }

                currentMessage = new Message(randomID, recipient, messageText);
                String lengthValidation = currentMessage.checkMessageLength();

                // Moves forward if the message length and content are fine
                if (!lengthValidation.equals("Message ready to send.")) {
                    JOptionPane.showMessageDialog(topFrame, lengthValidation);
                } else {
                    break;
                }
            }

            // Checks that the generated message ID is not too long
            if (!currentMessage.checkMessageID()) {
                JOptionPane.showMessageDialog(topFrame, "Error: Message ID exceeds 10 characters.");
                i--;
                continue;
            }

            // Shows the action choices and adds 1 if the message is sent
            String actionResult = currentMessage.SentMessage();
            if ("Sent".equals(actionResult)) {
                sessionMessagesSent++;
            }
        }
        
        // Shows the total number of successfully sent messages at the end
        JOptionPane.showMessageDialog(topFrame, 
            "All messages have been processed.\nTotal messages sent: " + sessionMessagesSent, 
            "Batch Complete", 
            JOptionPane.INFORMATION_MESSAGE
        );
             topFrame.dispose();
    }
}  