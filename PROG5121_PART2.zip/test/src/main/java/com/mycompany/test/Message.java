package com.mycompany.test;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Message {
    private String messageID;
    private String recipientCell;
    private String messageText;
    private String messageHash;

    private static ArrayList<Message> sentMessagesList = new ArrayList<>();
    private static int totalMessagesSent = 0;

    // Creates a new message object and builds its hash
    public Message(String messageID, String recipientCell, String messageText) { 
        this.messageID = messageID;
        this.recipientCell = recipientCell;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    // Checks that the message ID is valid and stays within the 10 character length
    public boolean checkMessageID() {
        return this.messageID != null && this.messageID.length() <= 10;
    }

    // Checks if the recipient's phone number format is valid
    public String checkRecipientCell() {
        if (this.recipientCell == null || this.recipientCell.trim().isEmpty()) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        String cleanCell = this.recipientCell.trim().replaceAll("[\\s-]", "");
        String saInternationalRegex = "^\\+27[6-8][0-9]{8}$";
        
        if (cleanCell.matches(saInternationalRegex)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Checks if the message text is empty or too long
    public String checkMessageLength() {
        if (this.messageText == null || this.messageText.trim().isEmpty()) {
            return "Invalid: Message content cannot be empty.";
        }
        if (this.messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = this.messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // Returns a text sentence showing the message ID
    public String getIDGenerationStatus() {
        return "Message ID generated: " + this.messageID;
    }

    // Returns test text to help check message actions
    public String simulateActionStatus(int choice) {
        return switch (choice) {
            case 1 -> "Message successfully sent.";
            case 2 -> "Press 0 to delete the message.";
            case 3 -> "Message successfully stored.";
            default -> "Cancelled";
        };
    }

    // Creates a unique uppercase hash code for the message
    public String createMessageHash() {
        if (this.messageText == null || this.messageText.trim().isEmpty()) {
            String shortID = this.messageID.length() >= 2 ? this.messageID.substring(0, 2) : this.messageID;
            return (shortID + ":" + totalMessagesSent + ":EMPTY").toUpperCase();
        }
        
        String cleanText = this.messageText.replaceAll("[?.!,:]", "");
        String[] words = cleanText.trim().split("\\s+");
        String first = words[0];
        String last = words[words.length - 1];
        
        String shortID = this.messageID.length() >= 2 ? this.messageID.substring(0, 2) : this.messageID;
        
        return (shortID + ":" + totalMessagesSent + ":" + first + last).toUpperCase();
    }

    // Shows the popup menu for Send, Disregard, or Store
    public String SentMessage() {
        String[] actions = {"Send", "Disregard", "Store"};
        
        while (true) {
            int action = JOptionPane.showOptionDialog(
                    null, 
                    "Choose an action for this message:", 
                    "Message Actions", 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE, 
                    null, 
                    actions, 
                    actions
                );

            switch (action) {
                // Handles the code if the user chooses to send the message
                case 0 -> {
                    totalMessagesSent++;
                    sentMessagesList.add(this);
                    
                    String displayDetails = "Message ID: " + this.messageID + "\n" +
                                            "Message Hash: " + this.messageHash + "\n" +
                                            "Recipient: " + this.recipientCell + "\n" +
                                            "Message: " + this.messageText;
                    
                    JOptionPane.showMessageDialog(null, displayDetails, "Message Sent Successfully", JOptionPane.INFORMATION_MESSAGE);
                    return "Sent";
                }
                // Asks for confirmation before discarding the message
                case 1 -> {
                    int confirmDiscard = JOptionPane.showConfirmDialog(
                        null, 
                        "Are you sure you want to discard this message?", 
                        "Confirm Discard", 
                        JOptionPane.YES_NO_OPTION, 
                        JOptionPane.WARNING_MESSAGE
                    );
                    
                    if (confirmDiscard == JOptionPane.YES_OPTION) {
                        JOptionPane.showMessageDialog(null, "Message disregarded.");
                        return "Disregarded";
                    }
                    continue; 
                }
                // Saves the message to the JSON file
                case 2 -> {
                    storeMessage();
                    return "Stored";
                }
                default -> {
                    return "Cancelled";
                }
            }
        }
    }

    // Creates a readable text log of all the messages sent
    public static String printMessages() {
        if (sentMessagesList.isEmpty()) {
            return "No messages have been sent during this session.";
        }
        StringBuilder sb = new StringBuilder("--- SENT MESSAGES LOG ---\n\n");
        for (Message msg : sentMessagesList) {
            sb.append("ID: ").append(msg.messageID)
              .append(" | To: ").append(msg.recipientCell)
              .append("\nMsg: ").append(msg.messageText)
              .append("\n-----------------------------------\n");
        }
        return sb.toString();
    }

    // Returns the total number of sent messages
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Prepares and formats the message data as a JSON block
    public void storeMessage() {
        File fileObj = new File("Jsonnew.json");
        boolean fileExists = fileObj.exists() && fileObj.length() > 0;
        StringBuilder jsonEntry = new StringBuilder();
        
        if (!fileExists) {
            jsonEntry.append("[\n");
        } else {
            jsonEntry.append(",\n");
        }
        
        jsonEntry.append("  {\n");
        jsonEntry.append("    \"MessageID\": \"").append(this.messageID).append("\",\n");
        jsonEntry.append("    \"MessageHash\": \"").append(this.messageHash).append("\",\n");
        jsonEntry.append("    \"Recipient\": \"").append(this.recipientCell).append("\",\n");
        jsonEntry.append("    \"Message\": \"").append(this.messageText.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("  }");

        // Appends the formatted data to the JSON file on disk
        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {
            file.write(jsonEntry.toString());
            JOptionPane.showMessageDialog(null, "Message successfully saved to Jsonnew.json");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to JSON file: " + e.getMessage());
        }
    }
}
